# DoR459_Proj

This Repo contains all parts of the project.

Current Task:
### Milestone 1
TO DO:
- data preprocessing
- exploratory analysis

PS: write code for Milestone 1 to be milestone1 branch

## Things to do:
- How to deal with missing values in locations:
- if lat and long are missing pick centre location of the state.
- threshhold for rejection is 50.
- truncate lat and long to 3 decimals
- group countries by continent and plot bar graph.
-
## missing data:
- age- ask on discussion board
- sex- probably drop all missing values
- impute lat and long

## Breakdown for Thursday meeting: 
### Work on part 1.1
- Oliver: age
- Rashid: Sex and date
- DJ: location  
