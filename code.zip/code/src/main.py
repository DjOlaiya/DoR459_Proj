#Packages
import pandas as pd
import numpy as np
import os

import matplotlib.pyplot as plt
from scipy import ndimage
import time 
import geopandas as gpd
from shapely.geometry import Point, Polygon, box
import math
from math import radians, cos, sin, asin, sqrt
import folium
from folium import plugins
#loading data

crs = {'init': 'epsg:4269'}

def ljoinonClosestCoord(case_df,loc_df,radius):

    loc_df.dropna(subset=['Lat','Long'],inplace=True)
    case_df.dropna(subset=['Lat','Long'],inplace=True)

    case_gdf = gpd.GeoDataFrame(case_df,crs=crs,geometry=gpd.points_from_xy(case_df.Long,case_df.Lat))
    loc_gdf = gpd.GeoDataFrame(loc_df,crs=crs,geometry=gpd.points_from_xy(loc_df.Long,loc_df.Lat))

    case_gdf.geometry= case_gdf.geometry.buffer(radius)
    mergeboth_gdf = gpd.sjoin(case_gdf,loc_gdf,how='left')
    mergeboth_gdf['dist_between_in_km'] = mergeboth_gdf.apply(lambda row: haversine(row['Long_left'],row['Lat_left'],row['Long_right'],row['Lat_right']),axis=1)
    dropCols = ['geometry']
    mergeboth_df = pd.DataFrame(mergeboth_gdf.drop(columns=dropCols))
    # mergeboth_df.to_csv(r'r5sjoin.csv')
    return mergeboth_gdf

def haversine(long1, lat1, long2=0, lat2=0):
    """
    Calculate the great circle distance between two points 
    on the earth (specified in decimal degrees)
    """
    # convert decimal degrees to radians 
    long1, lat1, long2, lat2 = map(radians, [long1, lat1, long2, lat2])

    # haversine formula 
    dist_long = long2 - long1 
    dist_lat = lat2 - lat1 
    a = sin(dist_lat/2)**2 + cos(lat1) * cos(lat2) * sin(dist_long/2)**2
    c = 2 * asin(sqrt(a)) 
    r = 6371 # Radius of earth in kilometers. Use 3956 for miles
    return c * r


trainData = pd.read_csv('../data/cases_train.csv')
testData = pd.read_csv('../data/cases_test.csv')
df_location = pd.read_csv('../data/location.csv')

#-------------------1.2 and 1.3 done together---------------------------------------------------------------------------
#-------------------DATA CLEANING FOR TEST DATA--------------------------------------------------------------------------
#-------------------Remove outlier of NaN rows (these rows has little to no data)------------------------------------------
trainData[trainData['latitude'].isnull()]
trainData = trainData.drop([26410,230376]).reset_index()

#Cleaning Age Attribute (we use binning)
changingToNaN = ['21-39','65-','13-19','22-80','21-61','13-69','18-65','8-68','33-78','0-19','20-39','60-','25-59','19-77','30-70','20-57','21-72','2-87','18-','11-80','18-99','50-69','18-50','40-69','16-80','28-35','0-18','13-65','40-89','34-66','9-69','80-','20-69','23-72','23-84','38-68','22-60','50-100','41-60','27-40','27-58','18-60','30-40','18 - 100','18-49','50-99','0-60','39-77','19-65','34-44','19-75','20-70','15-88','4-64','17-66','17-65','30-35','0-10']
#these are the values that simply do not work with our binning strategies, therefore for analysis we will change these values to NaN instead
for i in changingToNaN:
    trainData['age'] = trainData['age'].replace({i:np.NaN})
#reasonings for changing values as well as deletion of certain age's are explained in document
trainData['age'] = trainData['age'].replace({'30-39':'39'})
trainData['age'] = trainData['age'].replace({'0-9':'9'})
trainData['age'] = trainData['age'].replace({'10-19':'19'})
trainData['age'] = trainData['age'].replace({'80+':'80'})   
trainData['age'] = trainData['age'].replace({'90+':'90'})
trainData['age'] = trainData['age'].replace({'85+':'85'})
trainData['age'] = trainData['age'].replace({'8 month':'0.67'})
trainData['age'] = trainData['age'].replace({'5 month':'0.42'})

i = 0
while i < len(trainData['age']): #iterating throuh database
    if type(trainData['age'][i]) == str: #skip NaN values
        x = trainData['age'][i]
        x = x.split('-') #split the string on '-' 
        if len(x) == 2: #these are the values that are a range
            trainData['age'] = trainData['age'].replace({trainData['age'][i]:x[0]}) #replace the range with simply the lower bound of range (this will be fine as we are binning on the whole range of all these values)
    
    i += 1

#because we are binning with on [0,4],[5,14],[15,34],[35,59],[60,79],[80+] (notice they are all tight boundaries) therefore we dont care about any values that are decimal and we can simply make all values int
trainData['age'] = pd.to_numeric(trainData['age'],downcast='integer')  

bins = [-0.1, 4, 14, 34, 59, 79, 150] #here we create the bins
trainData['binned'] =  np.searchsorted(bins, trainData['age'].values)
trainData['age'] = trainData['binned'] #replace age column with binned column
trainData = trainData.drop(['binned'], axis=1)

#--------------------------------Impute 'Unknown' for missing sex, province, additional_information, and source----------------------------
trainData['sex'] = trainData['sex'].fillna('Unknown')
trainData['province'] = trainData['province'].fillna('Unknown')
trainData['additional_information'] = trainData['additional_information'].fillna('Unknown')
trainData['source'] = trainData['source'].fillna('Unknown')

#Only rows with missing country had a province of Taiwan so fill country column with Taiwan
trainData['country'] = trainData['country'].fillna('Taiwan')

#-------------------------------Impute mean date for date column and clean dates that give a range----------------------------------------
def split_date(datestr):
    if datestr == np.nan:
        return np.nan
    elif '-' in str(datestr):
        
        div = datestr.split('-')[0] #take the first date
#         print(f'the string was {datestr} the split is {div}')
        return div
    else:
        return datestr


trainData['date_confirmation'] = trainData['date_confirmation'].apply(split_date)
meandate = pd.to_datetime(trainData.date_confirmation).mean().date()
the_date = str(meandate.day) + '.' + str(meandate.month) + '.' + str(meandate.year)
trainData['date_confirmation'] = trainData['date_confirmation'].fillna(the_date) # fill date with mean date
trainData['date_confirmation'] = pd.to_datetime(trainData['date_confirmation'].apply(lambda x: str.strip(x)))

trainData2 = trainData.copy(deep=True)
locationData2 = df_location.copy(deep=True)

trainData2.rename(columns={'latitude':'Lat','longitude':'Long'},inplace=True)
locationData2.rename(columns={'Lat':'Lat','Long_':'Long'},inplace=True)

train_final = ljoinonClosestCoord(trainData2,locationData2,3)
train_final = train_final.drop(['index_right','Lat_left','Long_left','geometry'],axis=1, errors='ignore')
train_final['dist_between_in_km'] = train_final['dist_between_in_km'].fillna(-1)
#keep the closest match
idx = train_final.groupby(['index'], sort=False)['dist_between_in_km'].transform(min) == train_final['dist_between_in_km']
train_final = train_final[idx]

print('done cases train')

train_final.to_csv('../results/cases_train_processed.csv')

#---------------------------CLEANING FOR TEST DATA-----------------------------------------------------------------------
#---------------------------Impute 'Unkownn' for sex, province, additional_information, source---------------------------

testData['sex'] = testData['sex'].fillna('Unknown')
testData['province'] = testData['province'].fillna('Unknown')
testData['additional_information'] = testData['additional_information'].fillna('Unknown')
testData['source'] = testData['source'].fillna('Unknown')

#---------------------------Cleaning date, same as training data----------------------------------------------------
testData['date_confirmation'] = testData['date_confirmation'].apply(split_date)
meandate = pd.to_datetime(testData.date_confirmation).mean().date()
the_date = str(meandate.day) + '.' + str(meandate.month) + '.' + str(meandate.year)
testData['date_confirmation'] = testData['date_confirmation'].fillna(the_date) # fill date with mean date
testData['date_confirmation'] = pd.to_datetime(testData['date_confirmation'].apply(lambda x: str.strip(x)))

#--------------------------Cleaning age, same as training data------------------------------------------------------
#similar to changing train data set. See document for further explanations 
changingToNaN = ['34-66','0-18','18-99','0-20','22-80','18-65','20-57','0-60','19-77','40-89','4-64','21-72','80-']
#these are the values that simply do not work with our binning strategies, therefore for analysis we will change these values to NaN instead
for i in changingToNaN:
    testData['age'] = testData['age'].replace({i:np.NaN})
#our convention with ages with reasonable bins sizes and high number of records that we want to keep is simply take the ceiling
testData['age'] = testData['age'].replace({'30-39':'39'})
testData['age'] = testData['age'].replace({'0-9':'9'})

testData['age'] = testData['age'].replace({'80+':'80'})   
testData['age'] = testData['age'].replace({'90+':'90'})
testData['age'] = testData['age'].replace({'85+':'85'})
testData['age'] = testData['age'].replace({'19-Oct':'0'})
testData['age'] = testData['age'].replace({'11 month':'0.91'})
testData['age'] = testData['age'].replace({'14-Oct':'0'})
testData['age'] = testData['age'].replace({'6 months':'0.5'})
testData['age'] = testData['age'].replace({'14-May':'0'})
testData['age'] = testData['age'].replace({'09-May':'0'})

i = 0
while i < len(testData['age']): #iterating throuh database
    if type(testData['age'][i]) == str: #skip NaN values
        x = testData['age'][i]
        x = x.split('-') #split the string on '-' 
        if len(x) == 2: #these are the values that are a range
            testData['age'] = testData['age'].replace({testData['age'][i]:x[0]}) #replace the range with simply the lower bound of range (this will be fine as we are binning on the whole range of all these values)
    
    i += 1

testData['age'] = pd.to_numeric(testData['age'],downcast='integer')
bins = [-0.1, 4, 14, 34, 59, 79, 150]
testData['binned'] =  np.searchsorted(bins, testData['age'].values)
testData['age'] = testData['binned']
testData = testData.drop(['binned'], axis=1)


testData2 = testData.copy(deep=True)

testData2.rename(columns={'latitude':'Lat','longitude':'Long'},inplace=True)

# test_final = ljoinonClosestCoord(testData2,locationData2,3)
# test_final = test_final.reset_index()
# test_final['dist_between_in_km'] = test_final['dist_between_in_km'].fillna(-1)
# #keep the closest match
# idx = test_final.groupby(['index'], sort=False)['dist_between_in_km'].transform(min) == test_final['dist_between_in_km']
# test_final = test_final[idx]

# test_final = test_final.drop(['index','index_right','Lat_left','Long_left','geometry'],axis=1, errors='ignore')

# test_final.to_csv('../results/cases_test_processed.csv')

#-------------------------1.4 Aggregate the dataa to the State level for USA-----------------------------

df_US = df_location[df_location['Country_Region'] == 'US']

#Group by state
df_state = df_US.groupby(['Country_Region','Province_State']).agg({
    'Lat':'first', #simply take the first lat/lon you see and use it for the state
    'Long_':'first',
    'Confirmed':'sum',
    'Deaths':'sum',
    'Recovered':'sum',
    'Active':'sum',
    'Incidence_Rate':'mean', #gets fixed below
    'Case-Fatality_Ratio':'sum' #gets fixed below
}).reset_index(level=0, drop=True) #get rid of USA in index
df_state['Case-Fatality_Ratio'] = df_state['Confirmed']/df_state['Deaths'] #recalculate case-fatality ratio
df_state = df_state.drop(['Diamond Princess','Grand Princess','Recovered'])

#EXTERNAL SOURCE population data of each state
df_pop = pd.read_csv('../data/State Populations.csv').rename({'State':'Province_State'},axis=1).set_index('Province_State')
df_state = df_state.join(df_pop)

df_state['Incidence_Rate'] = (df_state['Confirmed'] / (df_state['2018 Population']/100000))
df_state = df_state.drop('2018 Population',axis=1)

df_state.to_csv('../results/location_transformed.csv')


